
package Model;

import java.io.Serializable;

public class ProductItem implements Serializable{
    String id;
    String title;
    String price;
    String recommend;
    String product_image;
    
    public ProductItem(String id, String title, String price, String recommend, String product_image){
        this.id = id;
        this.title = title;
        this.price = price;
        this.recommend = recommend;
        this.product_image = product_image;
    }
    public String getId(){
        return id;
    }
    public String getTitle(){
        return title;
    }
    public String getPrice(){
        return price;
    }
    public String getRecommend(){
        return recommend;
    }
}
