/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedHashMap;


public class LocalDB {
    /**
     * save product list to database
     * @param product_map 
     */
    public static void saveProductToStorage(LinkedHashMap<String, ProductItem> product_map) {

        FileOutputStream fout = null;
        ObjectOutputStream oos = null;
        try {
            String database_folder = "Database";
            File database_folder_path = new File(database_folder);
            if(!database_folder_path.exists()){
                database_folder_path.mkdir();
            }
            fout = new FileOutputStream(database_folder + File.separator + "product.pt");
            oos = new ObjectOutputStream(fout);
            oos.writeObject(product_map);
            System.out.println("Done");

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (fout != null) {
                try {
                    fout.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    /**
     * read database from local database
     * @param path
     * @return 
     */
    public static LinkedHashMap<String, ProductItem> readProductsFromStorage(String path) {
        LinkedHashMap<String, ProductItem> product_list = new LinkedHashMap<String, ProductItem>();
        try {
            FileInputStream fileIn = new FileInputStream(path);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            product_list = (LinkedHashMap<String, ProductItem>)objectIn.readObject();
            objectIn.close();
            return product_list;

        } catch (Exception ex) {
            return product_list;
        }
    }
}
