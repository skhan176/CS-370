package Contoller;

import Model.LocalDB;
import Model.ProductItem;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class LoadProducts {

    public static LinkedHashMap<String, ProductItem> product_map = new LinkedHashMap<String, ProductItem>();
    public static List<ProductItem> product_list = new ArrayList<ProductItem>();

    /**
     * read all products from database
     */
    public static void initProducts() {
        product_map.clear();
        product_list.clear();

        product_map = LocalDB.readProductsFromStorage("Database" + File.separator + "product.pt");
        for (String key : product_map.keySet()) {
            ProductItem model = product_map.get(key);
            product_list.add(model);
        }
    }

    public static boolean valid() {
        if (product_list == null || product_list.isEmpty()) {
            return false;
        }
        if (product_map == null || product_map.isEmpty()) {
            return false;
        }
        return true;
    }
}
