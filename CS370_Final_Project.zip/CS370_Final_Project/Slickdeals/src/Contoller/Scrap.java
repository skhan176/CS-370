/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Contoller;

import WebPageReader.Jsoup;
import WebPageReader.elements.Element;
import WebPageReader.choose.Elements;
import Model.LocalDB;
import Model.ProductItem;
import Slickdeals.Indicator;
import WebPageReader.elements.Document;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedHashMap;
import javafx.application.Platform;
import javafx.concurrent.Task;

public class Scrap {

    private static boolean check_flag = false;

    /**
     * import process
     *
     * @param file
     */
    public static void importProcess() {
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                try {
                    importProducts();
                    Platform.runLater(() -> {
                        Indicator.product_view.loadProducts();
                    });
                } catch (Exception e) {
                    Platform.runLater(() -> {
                        Indicator.product_view.enable();
                    });
                }
                return null;
            }
        };
        task.setOnFailed(e -> {
            Throwable exception = e.getSource().getException();
            if (exception != null) {
                Indicator.product_view.enable();
            }
        });
        task.setOnSucceeded(e -> {
            Indicator.product_view.enable();
        });
        new Thread(task).start();
        Indicator.product_view.disable();
    }

    /**
     * Scrap product from site product name, review, rate, product image is
     * scrapped from site
     */
    private static void importProducts() {
        try {
            File product_img_folder = new File("Products/");
            if (!product_img_folder.exists()) {
                product_img_folder.mkdir();
            }
            int id = 1;
            LinkedHashMap<String, ProductItem> product_map = new LinkedHashMap<String, ProductItem>();
            try {
                Document doc = Jsoup.connect("https://slickdeals.net/").get();
                Elements ul_elements = doc.getElementsByClass("dealTiles gridDeals");
                for (Element element : ul_elements) {
                    if (!element.hasAttr("data-role")) {
                        continue;
                    }
                    String attr_name = element.attr("data-role");
                    if (!attr_name.equals("deal-tiles")) {
                        continue;
                    }
                    Elements product_elements = element.getElementsByTag("li");
                    for (Element root_element : product_elements) {
                        try {
                            Element image_container = root_element.getElementsByClass("imageContainer ").first();
                            Element product_img_area = image_container.getElementsByTag("img").first();
                            if (product_img_area == null) {
                                continue;
                            }
                            String product_img_url = product_img_area.absUrl("data-original");
                            //download product
                            downloadImage(product_img_url, product_img_folder.getAbsolutePath() + File.separator + "product-" + id + ".jpg");
                            Element item_title = root_element.getElementsByClass("itemTitle").first();
                            String title = "";
                            if(item_title != null){
                                title = item_title.text();
                            }
                            Element item_price = root_element.getElementsByClass("itemPrice   ").first();
                            String price = "$0";
                            if(item_price != null){
                                price = item_price.text();
                            }
                            Element recommend_item = root_element.getElementsByClass("count").first();
                            String recommend = "0";
                            if(recommend_item != null){
                                recommend = recommend_item.text();
                            }
                            String id_str = String.valueOf(id);
                            ProductItem model = new ProductItem(id_str, title, price, recommend, "product-" + id + ".jpg");
                            product_map.put(id_str, model);
                            id++;
                        } catch (Exception e) {
                            //System.err.println("Error");
                        }
                    }
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            //save product list to local storage
            LocalDB.saveProductToStorage(product_map);
            //initialize all data again
            LoadProducts.initProducts();
        } catch (Exception e) {

        }
    }

    private static void downloadImage(String src, String path) {
        //Open a URL Stream
        try (BufferedInputStream in = new BufferedInputStream(new URL(src).openStream());
                FileOutputStream fileOutputStream = new FileOutputStream(path)) {
            byte dataBuffer[] = new byte[1024];
            int bytesRead;
            while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                fileOutputStream.write(dataBuffer, 0, bytesRead);
            }
            fileOutputStream.close();
            in.close();
        } catch (IOException e) {
            // handle exception
        }
    }
}
