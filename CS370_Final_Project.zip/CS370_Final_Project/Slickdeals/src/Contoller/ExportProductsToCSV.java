
package Contoller;

import Model.ProductItem;
import View.FileChooserDialog;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import javafx.collections.ObservableList;


public class ExportProductsToCSV {
    public static ObservableList<ProductItem> product_list = null;
    
    private static String csvFormat(String[] array) {
        if (array == null || array.length == 0) {
            return null;
        }
        String csv_str = "";
        for (int i = 0; i < array.length; i++) {
            if (i == array.length - 1) {
                if (array[i].contains(",")) {
                    csv_str += "\"" + array[i] + "\"" + ",";
                } else {
                    csv_str += array[i] + ",";
                }
                break;
            }
            if (array[i].contains(",")) {
                csv_str += "\"" + array[i] + "\"" + ",";
            } else {
                csv_str += array[i] + ",";
            }
        }
        return csv_str;
    }

    /**
     * export product to csv file
     * @param file
     */
    public static void export() {
        File export_file = FileChooserDialog.showSaveDialog(FileChooserDialog.FilterMode.CSV_FILES);
        if (export_file == null) {
            return;
        }
        BufferedWriter csv_writer = null;
        try {
            csv_writer = new BufferedWriter(new FileWriter(export_file));
            String[] headerRecord = {"Id", "Title", "Price", "Recommend"};
            csv_writer.write(csvFormat(headerRecord));
            csv_writer.newLine();
            for (ProductItem item : product_list) {
                String[] record = generateContent(item);
                csv_writer.write(csvFormat(record));
                csv_writer.newLine();
            }
        } catch (Exception e) {

        } finally {
            if (csv_writer != null) {
                try {
                    csv_writer.close();
                } catch (Exception e) {

                }
            }
        }
    }

    private static String[] generateContent(ProductItem model) {
        String[] content = new String[4];
        content[0] = model.getId();
        content[1] = model.getTitle();
        content[2] = model.getPrice();
        content[3] = model.getRecommend();
        return content;
    }
}
