
package Slickdeals;

import View.ProductView;


public class Indicator {
    public static LogoManager logo = new LogoManager();
    public static ProductView product_view = new ProductView();
}
