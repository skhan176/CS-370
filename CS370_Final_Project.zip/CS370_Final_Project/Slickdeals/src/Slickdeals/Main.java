
package Slickdeals;

import Contoller.LoadProducts;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;


public class Main extends Application {

    public static Stage productStage;

    @Override
    public void start(Stage primaryStage) {
        Windows.initWindowSize();
        LoadProducts.initProducts();
        productStage = new Stage();
        initWindow();
    }

    public void initWindow() {
        Indicator.product_view.initView();
        Scene scene = new Scene(Indicator.product_view.data_enter_pane);
        scene.getStylesheets().add(getClass().getClassLoader().getResource("style/UIStyle.css").toExternalForm());
        productStage.setScene(scene);
        productStage.setMaximized(true);
        productStage.initStyle(StageStyle.DECORATED);
        productStage.getIcons().add(Indicator.logo.getIcon());
        productStage.setTitle("Slickdeals");
        productStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                try {
                    System.exit(0);
                } catch (Exception e) {
                    System.exit(0);
                }
            }
        });
        productStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
