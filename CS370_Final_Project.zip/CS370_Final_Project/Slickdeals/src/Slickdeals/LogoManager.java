/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Slickdeals;

import java.io.InputStream;
import javafx.scene.image.Image;

/**
 *
 * @author Star
 */
public class LogoManager {
    public Image getIcon(){
        InputStream icon_stream = getClass().getClassLoader().getResourceAsStream("Slickdeals/icon.png");
        return new Image(icon_stream);
    }
    public Image getPlus(){
        InputStream icon_stream = getClass().getClassLoader().getResourceAsStream("Slickdeals/plus.png");
        return new Image(icon_stream);
    }
    public Image getCluster(){
        InputStream icon_stream = getClass().getClassLoader().getResourceAsStream("Slickdeals/node.png");
        return new Image(icon_stream);
    }
    public Image getLoading(){
        InputStream icon_stream = getClass().getClassLoader().getResourceAsStream("Slickdeals/loading.gif");
        return new Image(icon_stream);
    }
    public String getURL(String location){
        String path = getClass().getClassLoader().getResource(location).toExternalForm();
        return path;
    }
}
