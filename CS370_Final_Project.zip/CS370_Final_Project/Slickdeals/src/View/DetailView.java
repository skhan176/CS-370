/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Contoller.Scrap;
import Contoller.LoadProducts;
import Model.ProductItem;
import Slickdeals.Main;
import Slickdeals.Indicator;
import Slickdeals.Windows;
import java.io.File;
import java.io.InputStream;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DetailView {

    private Stage detail_stage;
    public static BorderPane detail_pane;
    public BorderPane detail_group_pane;

    public ScrollPane main_pane;

    public Label title_label = new Label();

    public Label product_title_label = new Label();
    public Label product_price_label = new Label();
    public Label product_recommend_label = new Label();

    public TextField product_title_field = new TextField();
    public TextField product_price_field = new TextField();
    public TextField product_recommend_field = new TextField();

    public ImageView product_view;

    private Button update_btn;
    private Button delete_btn;
    private Button close_btn;

    private HBox titleBox;

    private GridPane main_pane1;

    private ProductItem product_item;

    public DetailView(ProductItem item) {
        this.product_item = item;
    }

    public void initView() {

        initMainArea();

        detail_group_pane = new BorderPane();
        detail_group_pane.setId("main_area");

        BorderPane.setMargin(main_pane1, new Insets(20, 10, 10, 25));
        detail_group_pane.setCenter(main_pane1);

        main_pane = new ScrollPane();
        main_pane.setStyle("-fx-background-color: #000000;");
        main_pane.setFitToWidth(true);
        main_pane.setFitToHeight(true);
        main_pane.setPannable(true);
        main_pane.setContent(detail_group_pane);

        detail_pane = new BorderPane();
        detail_pane.setId("black_area");
        BorderPane.setMargin(titleBox, new Insets(5, 0, 0, 0));
        detail_pane.setTop(titleBox);
        BorderPane.setMargin(main_pane, new Insets(5, 0, 0, 0));
        detail_pane.setCenter(main_pane);

        Scene scene = new Scene(detail_pane);
        scene.getStylesheets().add(getClass().getClassLoader().getResource("style/UIStyle.css").toExternalForm());

        detail_stage = new Stage();
        detail_stage.setScene(scene);
        detail_stage.setResizable(false);
        detail_stage.setTitle("Detail");
        detail_stage.getIcons().add(Indicator.logo.getIcon());

        detail_stage.initOwner(Main.productStage);
        detail_stage.initModality(Modality.WINDOW_MODAL);
    }

    public void show() {
        detail_stage.showAndWait();
    }

    private void initMainArea() {
        product_title_label.setId("roundLabel");
        product_title_label.setText("Title: ");

        product_price_label.setId("roundLabel");
        product_price_label.setText("Price: ");

        product_recommend_label.setId("roundLabel");
        product_recommend_label.setText("Recommend: ");

        product_title_field.setId("round");
        product_title_field.setPrefWidth(400);

        product_price_field.setId("round");
        product_price_field.setPrefWidth(400);

        product_recommend_field.setId("round");
        product_recommend_field.setPrefWidth(400);

        initBtns();

        main_pane1 = new GridPane();
        main_pane1.setId("main_area");
        main_pane1.setPadding(new Insets(5, 0, 0, 0));
        main_pane1.setHgap(20);
        main_pane1.setVgap(10);
        main_pane1.setAlignment(Pos.TOP_CENTER);

        initDetailArea();
        initTitleArea();
    }

    private void initBtns() {
        update_btn = new Button();
        update_btn.setId("mainbtn");
        update_btn.setText("Save");
        update_btn.setCursor(Cursor.HAND);
        update_btn.setTextAlignment(TextAlignment.CENTER);

        delete_btn = new Button();
        delete_btn.setId("mainbtn");
        delete_btn.setText("Remove");
        delete_btn.setCursor(Cursor.HAND);
        delete_btn.setTextAlignment(TextAlignment.CENTER);
        
        close_btn = new Button();
        close_btn.setId("mainbtn");
        close_btn.setText("Close");
        close_btn.setCursor(Cursor.HAND);
        close_btn.setTextAlignment(TextAlignment.CENTER);

        update_btn.setOnAction((evt) -> {
            try {
                String title = product_title_field.getText();
                String price = product_price_field.getText();
                String reccomend = product_recommend_field.getText();
                if (title == null || title.isEmpty()) {
                    return;
                }
                if (price == null || price.isEmpty()) {
                    return;
                }
                if (reccomend == null || reccomend.isEmpty()) {
                    return;
                }

                ProductItem new_item = new ProductItem(product_item.getId(), title, price, reccomend, price);
                LoadProducts.product_map.put(product_item.getId(), new_item);
                for (int i = 0; i < LoadProducts.product_list.size(); i++) {
                    ProductItem item = LoadProducts.product_list.get(i);
                    if (item.getId().equals(product_item.getId())) {
                        LoadProducts.product_list.set(i, new_item);
                        break;
                    }
                }
                Indicator.product_view.loadProducts();
                detail_stage.close();
            } catch (Exception e) {
            }
        });
        delete_btn.setOnAction((evt) -> {
            LoadProducts.product_map.remove(product_item.getId());
            for (int i = 0; i < LoadProducts.product_list.size(); i++) {
                ProductItem item = LoadProducts.product_list.get(i);
                if (item.getId().equals(product_item.getId())) {
                    LoadProducts.product_list.remove(i);
                    break;
                }
            }
            Indicator.product_view.loadProducts();
            detail_stage.close();
        });
        close_btn.setOnAction((evt) -> {
            detail_stage.close();
        });
    }
    /**
     * Initialize detail area
     */
    private void initDetailArea() {

        HBox btnBox = new HBox();
        btnBox.setAlignment(Pos.CENTER_RIGHT);
        btnBox.setSpacing(15);
        btnBox.getChildren().addAll(update_btn, delete_btn, close_btn);

        main_pane1.getChildren().clear();
        Separator sep1 = new Separator();
        sep1.setOrientation(Orientation.VERTICAL);

        main_pane1.add(product_title_label, 0, 0, 1, 1);
        main_pane1.add(product_price_label, 0, 1, 1, 1);
        main_pane1.add(product_recommend_label, 0, 2, 1, 1);

        main_pane1.add(product_title_field, 1, 0, 1, 1);
        main_pane1.add(product_price_field, 1, 1, 1, 1);
        main_pane1.add(product_recommend_field, 1, 2, 1, 1);

        Separator sep = new Separator(Orientation.HORIZONTAL);

        product_title_field.setText(product_item.getTitle());
        product_price_field.setText(product_item.getPrice());
        product_recommend_field.setText(product_item.getRecommend());

        File image_file = new File("Products" + File.separator + "product-" + product_item.getId() + ".jpg");
        if (image_file.exists()) {
            try {
                product_view = new ImageView();
                product_view.setImage(new Image(image_file.toURI().toURL().toExternalForm()));
                product_view.setFitWidth(140);
                product_view.setFitWidth(120);
                HBox imageBox = new HBox();
                imageBox.setAlignment(Pos.CENTER);
                imageBox.getChildren().addAll(product_view);
                main_pane1.add(imageBox, 0, 3, 2, 1);
                main_pane1.add(sep, 0, 4, 2, 1);
                main_pane1.add(btnBox, 0, 5, 2, 1);
            } catch (Exception e) {
                e.printStackTrace();
                main_pane1.add(sep, 0, 3, 2, 1);
                main_pane1.add(btnBox, 0, 4, 2, 1);
            }
        } else {
            main_pane1.add(sep, 0, 3, 2, 1);
            main_pane1.add(btnBox, 0, 4, 2, 1);
        }
    }

    private void initTitleArea() {
        title_label.setText("Detail");
        title_label.setId("title_label");
        titleBox = new HBox();
        titleBox.setSpacing(25);
        titleBox.setAlignment(Pos.CENTER);

        titleBox.getChildren().addAll(title_label);
    }
}
