package View;

import Contoller.ExportProductsToCSV;
import Contoller.Scrap;
import Contoller.LoadProducts;
import Model.ProductItem;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import Slickdeals.Windows;
import Slickdeals.Indicator;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableRow;
import javafx.scene.control.ToggleGroup;

public class ProductView {

    public BorderPane data_enter_pane;
    public BorderPane data_enter_group_pane;

    public ScrollPane main_pane;

    public Label title_label = new Label();

    public Label url_label = new Label();
    public TextField url_field = new TextField();

    public Label search_label = new Label();
    public TextField search_field = new TextField();

    public TableView<ProductItem> product_list_view;
    public ObservableList<ProductItem> product_list;
    public ObservableList<ProductItem> buf_product_list;

    private Button process_btn;
    private Button search_btn;
    private Button export_btn;

    private RadioButton title_search_option;
    private RadioButton recommend_search_option;

    private HBox titleBox;

    private GridPane main_pane1;

    public ProductView() {

    }

    public void initView() {
        initEdit();
        data_enter_group_pane = new BorderPane();
        data_enter_group_pane.setId("main_area");
        BorderPane.setMargin(main_pane1, new Insets(20, 10, 10, 25));
        data_enter_group_pane.setTop(main_pane1);
        data_enter_group_pane.setCenter(product_list_view);

        main_pane = new ScrollPane();
        main_pane.setStyle("-fx-background-color: #000000;");
        main_pane.setFitToWidth(true);
        main_pane.setFitToHeight(true);
        main_pane.setPannable(true);
        main_pane.setContent(data_enter_group_pane);

        data_enter_pane = new BorderPane();
        data_enter_pane.setPrefWidth(Windows.WINDOW_WIDTH);
        data_enter_pane.setId("black_area");
        BorderPane.setMargin(titleBox, new Insets(5, 0, 0, 0));
        data_enter_pane.setTop(titleBox);
        BorderPane.setMargin(main_pane, new Insets(5, 0, 0, 0));
        data_enter_pane.setCenter(main_pane);
    }

    private void initEdit() {
        url_label.setId("roundLabel");
        url_label.setText("URL*: ");

        url_field.setId("round");
        url_field.setPrefWidth(400);
        url_field.setText("https://slickdeals.net/");
        url_field.setEditable(false);

        search_label.setId("roundLabel");
        search_label.setText("Search: ");

        search_field.setId("round");
        search_field.setPrefWidth(400);
        search_field.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            if (oldValue != null && (newValue.length() < oldValue.length())) {
                product_list = FXCollections.observableArrayList(buf_product_list);
            }
            String value = newValue.toLowerCase();
            if(value == null || value.isEmpty()){
                product_list = FXCollections.observableArrayList(buf_product_list);
                product_list_view.setItems(product_list);
                return;
            }
            product_list.clear();

            long count = product_list_view.getColumns().stream().count();
            for (int i = 0; i < buf_product_list.size(); i++) {
                for (int j = 0; j < count; j++) {
                    String entry = "";
                    if (title_search_option.isSelected()) {
                        entry = "" + buf_product_list.get(i).getTitle();
                        if (entry.toLowerCase().startsWith(value)) {
                            product_list.add(buf_product_list.get(i));
                            break;
                        }
                    } else if (recommend_search_option.isSelected()) {
                        entry = "" + buf_product_list.get(i).getRecommend();
                        if (entry.equalsIgnoreCase(value)) {
                            product_list.add(buf_product_list.get(i));
                            break;
                        }
                    }
                }
            }
            product_list_view.setItems(product_list);
        });

        initBtns();

        main_pane1 = new GridPane();
        main_pane1.setId("main_area");
        main_pane1.setPadding(new Insets(15, 0, 0, 0));
        main_pane1.setHgap(20);
        main_pane1.setVgap(10);
        main_pane1.setAlignment(Pos.TOP_CENTER);

        initProductListView(); //init product list view
        loadProducts();//load products
        initMainArea();
        initTitleArea();
    }

    /**
     * init product list view
     */
    public void initProductListView() {
        product_list_view = new TableView<ProductItem>();
        product_list_view.setId("customer_table");
        product_list_view.setPlaceholder(new Label("Sorry! There is no any product."));
        product_list_view.setPrefHeight(Windows.WINDOW_HEIGHT);
        product_list_view.setPrefWidth(Windows.WINDOW_WIDTH - 20);

        product_list_view.setRowFactory(tv -> {
            TableRow<ProductItem> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                DetailView detail_view = new DetailView(row.getItem());
                detail_view.initView();
                detail_view.show();
            });
            return row;
        });

        product_list_view.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        TableColumn<ProductItem, String> id = new TableColumn<>("Id");
        TableColumn<ProductItem, String> title = new TableColumn<>("Title");
        TableColumn<ProductItem, String> price = new TableColumn<>("Price");
        TableColumn<ProductItem, String> recommend = new TableColumn<>("Recommend");

        id.setCellValueFactory(new PropertyValueFactory<ProductItem, String>("Id"));
        title.setCellValueFactory(new PropertyValueFactory<ProductItem, String>("Title"));
        price.setCellValueFactory(new PropertyValueFactory<ProductItem, String>("Price"));
        recommend.setCellValueFactory(new PropertyValueFactory<ProductItem, String>("Recommend"));

        id.prefWidthProperty().bind(product_list_view.widthProperty().multiply(0.08));
        title.prefWidthProperty().bind(product_list_view.widthProperty().multiply(0.72));
        price.prefWidthProperty().bind(product_list_view.widthProperty().multiply(0.1));
        recommend.prefWidthProperty().bind(product_list_view.widthProperty().multiply(0.1));

        id.setResizable(false);
        title.setResizable(false);
        price.setResizable(false);
        recommend.setResizable(false);

        product_list_view.getColumns().addListener(new ListChangeListener() {
            public boolean suspended;

            @Override
            public void onChanged(ListChangeListener.Change change) {
                change.next();
                if (change.wasReplaced() && !suspended) {
                    this.suspended = true;
                    product_list_view.getColumns().setAll(id, title, price, recommend);
                    this.suspended = false;
                }
            }
        });

        product_list_view.getColumns().addAll(id, title, price, recommend);
        product_list = FXCollections.observableArrayList();
        buf_product_list = FXCollections.observableArrayList();
        product_list_view.setItems(product_list);
    }

    /**
     * load products
     */
    public void loadProducts() {
        product_list.clear();
        product_list.addAll(LoadProducts.product_list);
        buf_product_list.addAll(LoadProducts.product_list);
    }

    /**
     * Init buttons
     */
    private void initBtns() {
        process_btn = new Button();
        process_btn.setId("mainbtn");
        process_btn.setText("Add Products");
        process_btn.setCursor(Cursor.HAND);
        process_btn.setTextAlignment(TextAlignment.CENTER);
        process_btn.setContentDisplay(ContentDisplay.LEFT);
        ImageView btn_img = new ImageView(Indicator.logo.getPlus());
        btn_img.setFitWidth(20);
        btn_img.setFitHeight(20);
        process_btn.setGraphic(btn_img);

        search_btn = new Button();
        search_btn.setId("mainbtn");
        search_btn.setText("Search");
        search_btn.setCursor(Cursor.HAND);
        search_btn.setTextAlignment(TextAlignment.CENTER);

        export_btn = new Button();
        export_btn.setId("mainbtn");
        export_btn.setText("Export");
        export_btn.setCursor(Cursor.HAND);
        export_btn.setTextAlignment(TextAlignment.CENTER);

        ToggleGroup group = new ToggleGroup();
        title_search_option = new RadioButton("Title");
        title_search_option.setId("radio");
        recommend_search_option = new RadioButton("Recommend");
        recommend_search_option.setId("radio");
        title_search_option.setToggleGroup(group);
        recommend_search_option.setToggleGroup(group);
        title_search_option.setSelected(true);

        process_btn.setOnAction((evt) -> {
            try {
                Scrap.importProcess();
            } catch (Exception e) {
                enable();
            }
        });
        
        export_btn.setOnAction((evt) -> {
            if (product_list == null || product_list.isEmpty()) {
                return;
            }
            ExportProductsToCSV.product_list = product_list;
            ExportProductsToCSV.export();
        });
    }

    /**
     * initialize main area
     */
    private void initMainArea() {

        HBox btnBox = new HBox();
        btnBox.setAlignment(Pos.CENTER_LEFT);
        btnBox.setSpacing(5);
        btnBox.getChildren().addAll(export_btn);

        HBox optionBox = new HBox();
        optionBox.setAlignment(Pos.CENTER);
        optionBox.setSpacing(25);
        optionBox.getChildren().addAll(title_search_option, recommend_search_option);

        main_pane1.getChildren().clear();
        Separator sep1 = new Separator();
        sep1.setOrientation(Orientation.VERTICAL);

        main_pane1.add(url_label, 0, 0, 1, 1);
        main_pane1.add(search_label, 0, 1, 1, 1);

        main_pane1.add(url_field, 1, 0, 1, 1);
        main_pane1.add(search_field, 1, 1, 1, 1);
        main_pane1.add(optionBox, 1, 2, 1, 1);

        main_pane1.add(process_btn, 2, 0, 1, 1);
        main_pane1.add(btnBox, 2, 1, 1, 1);
    }

    /**
     * Top title bar
     */
    private void initTitleArea() {
        title_label.setText(Windows.TITLE);
        title_label.setId("title_label");
        titleBox = new HBox();
        titleBox.setSpacing(25);
        titleBox.setAlignment(Pos.CENTER);

        titleBox.getChildren().addAll(title_label);
    }

    public void disable() {
        process_btn.setText("Processing...");
        process_btn.setDisable(true);
        export_btn.setDisable(true);
    }

    public void enable() {
        process_btn.setText("Add Products");
        process_btn.setDisable(false);
        export_btn.setDisable(false);
    }
}
